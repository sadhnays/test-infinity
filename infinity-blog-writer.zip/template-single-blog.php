<?php
/**
 * Template Name: Single Blog Post - Infinity SoftHub
 * Description: Beautiful single post layout for blog posts
 */

if (!defined('ABSPATH')) {
    wp_redirect(home_url());
    exit;
}

// Get post data
$post_id = get_the_ID();
$categories = get_the_category();
$tags = get_the_tags();
$author_id = get_post_field('post_author', $post_id);
$author_name = get_the_author();
$author_avatar = get_avatar_url($author_id, array('size' => 80));
$author_bio = get_the_author_meta('description', $author_id);
$views = get_post_meta($post_id, 'post_views_count', true) ?: rand(50, 500);
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php the_title(); ?> - <?php bloginfo('name'); ?></title>
    <meta name="description" content="<?php echo wp_trim_words(get_the_excerpt(), 30); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <?php wp_head(); ?>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background: #F5F7FB; color: #0F172A; line-height: 1.6; }
        .site-header { background: linear-gradient(135deg, #062B6F 0%, #0B3D91 100%); padding: 15px 0; }
        .site-header .container { display: flex; justify-content: space-between; align-items: center; max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        .site-logo { color: #fff; font-size: 24px; font-weight: 700; text-decoration: none; }
        .site-nav { display: flex; gap: 25px; }
        .site-nav a { color: rgba(255,255,255,0.9); text-decoration: none; font-weight: 500; }
        .post-hero { background: linear-gradient(135deg, #062B6F 0%, #0B3D91 50%, #2563EB 100%); padding: 80px 20px 50px; text-align: center; color: #fff; position: relative; }
        .post-hero::before { content: ''; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E"); }
        .breadcrumb { display: flex; justify-content: center; align-items: center; gap: 10px; margin-bottom: 25px; font-size: 14px; position: relative; }
        .breadcrumb a { color: rgba(255,255,255,0.8); text-decoration: none; }
        .breadcrumb span { color: rgba(255,255,255,0.6); }
        .post-category { display: inline-block; padding: 8px 20px; background: linear-gradient(135deg, #2563EB, #062B6F); border-radius: 25px; font-size: 13px; font-weight: 600; margin-bottom: 20px; text-transform: uppercase; }
        .post-title { font-size: 42px; font-weight: 700; margin-bottom: 25px; line-height: 1.3; position: relative; }
        .post-meta { display: flex; justify-content: center; flex-wrap: wrap; gap: 25px; font-size: 15px; }
        .post-meta-item { display: flex; align-items: center; gap: 8px; }
        .post-meta-item i { color: #3B82F6; }
        .post-container { max-width: 900px; margin: 0 auto; padding: 50px 20px; }
        .back-btn { display: inline-flex; align-items: center; gap: 10px; margin-bottom: 30px; padding: 12px 24px; background: #fff; color: #062B6F; border-radius: 10px; text-decoration: none; font-weight: 600; box-shadow: 0 2px 10px rgba(0,0,0,0.08); transition: all 0.3s; }
        .back-btn:hover { transform: translateX(-5px); }
        .featured-image { width: 100%; max-height: 500px; object-fit: cover; border-radius: 20px; margin-bottom: 40px; box-shadow: 0 10px 40px rgba(0,0,0,0.15); }
        .featured-placeholder { width: 100%; height: 400px; background: linear-gradient(135deg, #062B6F, #2563EB); border-radius: 20px; display: flex; align-items: center; justify-content: center; margin-bottom: 40px; }
        .featured-placeholder i { font-size: 80px; color: rgba(255,255,255,0.3); }
        .post-content { font-size: 17px; line-height: 1.9; color: #1E293B; }
        .post-content p { margin-bottom: 25px; }
        .post-content h2 { color: #062B6F; font-size: 28px; margin: 40px 0 20px; }
        .post-content h3 { color: #062B6F; font-size: 22px; margin: 30px 0 15px; }
        .post-content ul, .post-content ol { margin: 20px 0; padding-left: 30px; }
        .post-content li { margin-bottom: 10px; }
        .post-content a { color: #2563EB; text-decoration: underline; }
        .post-content blockquote { border-left: 4px solid #2563EB; padding: 20px 30px; margin: 30px 0; background: #F5F7FB; border-radius: 0 10px 10px 0; font-style: italic; color: #64748B; }
        .post-tags-section { margin-top: 50px; padding-top: 30px; border-top: 2px solid #E5EAF3; }
        .post-tags-title { font-size: 16px; font-weight: 600; color: #062B6F; margin-bottom: 15px; }
        .post-tags { display: flex; flex-wrap: wrap; gap: 10px; }
        .post-tag { padding: 8px 18px; background: #F5F7FB; color: #64748B; border-radius: 20px; text-decoration: none; font-size: 14px; transition: all 0.3s; }
        .post-tag:hover { background: #2563EB; color: #fff; }
        .post-share { display: flex; align-items: center; gap: 15px; margin-top: 30px; }
        .post-share-label { font-weight: 600; color: #062B6F; }
        .share-buttons { display: flex; gap: 10px; }
        .share-btn { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; color: #fff; text-decoration: none; transition: all 0.3s; }
        .share-btn:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
        .facebook { background: #1877F2; }
        .twitter { background: #1DA1F2; }
        .linkedin { background: #0A66C2; }
        .whatsapp { background: #25D366; }
        .author-box { display: flex; align-items: center; gap: 20px; padding: 30px; background: linear-gradient(135deg, #062B6F 0%, #0B3D91 100%); border-radius: 20px; margin-top: 50px; color: #fff; }
        .author-avatar { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid rgba(255,255,255,0.3); }
        .author-info h4 { font-size: 18px; margin-bottom: 5px; }
        .author-info p { font-size: 14px; opacity: 0.9; }
        .related-posts { margin-top: 60px; }
        .related-title { font-size: 24px; font-weight: 700; color: #062B6F; margin-bottom: 30px; text-align: center; }
        .related-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 25px; }
        .related-card { background: #fff; border-radius: 15px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.08); text-decoration: none; color: inherit; transition: all 0.3s; }
        .related-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.15); }
        .related-image { width: 100%; height: 150px; object-fit: cover; }
        .related-card-title { padding: 15px; font-size: 16px; font-weight: 600; color: #062B6F; line-height: 1.4; }
        .site-footer { background: #062B6F; color: #fff; padding: 40px 20px; text-align: center; margin-top: 60px; }
        @media (max-width: 768px) { .post-title { font-size: 28px; } .post-meta { flex-direction: column; gap: 10px; } .related-grid { grid-template-columns: 1fr; } .author-box { flex-direction: column; text-align: center; } }
    </style>
</head>
<body>
    <header class="site-header">
        <div class="container">
            <a href="<?php echo home_url(); ?>" class="site-logo">Infinity SoftHub</a>
            <nav class="site-nav">
                <a href="<?php echo home_url(); ?>">Home</a>
                <a href="<?php echo home_url('/blog'); ?>">Blog</a>
            </nav>
        </div>
    </header>
    <section class="post-hero">
        <div class="breadcrumb">
            <a href="<?php echo home_url('/blog'); ?>">Blog</a>
            <span>/</span>
            <span><?php the_title(); ?></span>
        </div>
        <?php if (!empty($categories)): ?>
            <span class="post-category"><?php echo esc_html($categories[0]->name); ?></span>
        <?php endif; ?>
        <h1 class="post-title"><?php the_title(); ?></h1>
        <div class="post-meta">
            <div class="post-meta-item"><i class="fas fa-calendar-alt"></i> <?php echo get_the_date('F d, Y'); ?></div>
            <div class="post-meta-item"><i class="fas fa-user"></i> <?php the_author(); ?></div>
            <div class="post-meta-item"><i class="fas fa-comment"></i> <?php comments_number('0 Comments', '1 Comment', '% Comments'); ?></div>
            <div class="post-meta-item"><i class="fas fa-eye"></i> <?php echo $views; ?> Views</div>
        </div>
    </section>
    <div class="post-container">
        <a href="<?php echo home_url('/blog'); ?>" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Blog</a>
        <?php if (has_post_thumbnail()): ?>
            <img src="<?php the_post_thumbnail_url('large'); ?>" alt="<?php the_title(); ?>" class="featured-image">
        <?php else: ?>
            <div class="featured-placeholder"><i class="fas fa-blog"></i></div>
        <?php endif; ?>
        <div class="post-content">
            <?php while (have_posts()) : the_post(); the_content(); endwhile; ?>
        </div>
        <?php if (!empty($tags)): ?>
            <div class="post-tags-section">
                <h4 class="post-tags-title"><i class="fas fa-tags"></i> Related Topics</h4>
                <div class="post-tags">
                    <?php foreach ($tags as $tag): ?>
                        <a href="<?php echo get_tag_link($tag->term_id); ?>" class="post-tag"><?php echo esc_html($tag->name); ?></a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
        <div class="post-share">
            <span class="post-share-label">Share:</span>
            <div class="share-buttons">
                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" target="_blank" class="share-btn facebook"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com/intent/tweet?url=<?php the_permalink(); ?>" target="_blank" class="share-btn twitter"><i class="fab fa-twitter"></i></a>
                <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>" target="_blank" class="share-btn linkedin"><i class="fab fa-linkedin-in"></i></a>
                <a href="https://wa.me/?text=<?php the_permalink(); ?>" target="_blank" class="share-btn whatsapp"><i class="fab fa-whatsapp"></i></a>
            </div>
        </div>
        <div class="author-box">
            <?php if ($author_avatar): ?>
                <img src="<?php echo $author_avatar; ?>" alt="<?php echo $author_name; ?>" class="author-avatar">
            <?php endif; ?>
            <div class="author-info">
                <h4><?php echo $author_name; ?></h4>
                <p><?php echo $author_bio ?: 'Technology enthusiast at Infinity SoftHub.'; ?></p>
            </div>
        </div>
        <?php
        $related = new WP_Query(array('post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 3, 'post__not_in' => array($post_id), 'cat' => !empty($categories) ? $categories[0]->term_id : 0));
        if ($related->have_posts()):
        ?>
            <div class="related-posts">
                <h3 class="related-title">Related Posts</h3>
                <div class="related-grid">
                    <?php while ($related->have_posts()): $related->the_post(); ?>
                        <a href="<?php the_permalink(); ?>" class="related-card">
                            <?php if (has_post_thumbnail()): ?>
                                <img src="<?php the_post_thumbnail_url('medium'); ?>" alt="<?php the_title(); ?>" class="related-image">
                            <?php else: ?>
                                <div class="related-image" style="background: linear-gradient(135deg, #062B6F, #2563EB);"></div>
                            <?php endif; ?>
                            <h4 class="related-card-title"><?php the_title(); ?></h4>
                        </a>
                    <?php endwhile; ?>
                </div>
            </div>
        <?php endif; wp_reset_postdata(); ?>
    </div>
    <footer class="site-footer"><p>&copy; <?php echo date('Y'); ?> Infinity SoftHub. All rights reserved.</p></footer>
    <?php wp_footer(); ?>
</body>
</html>